package com.example.minggu9

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
